package vo;

public class AllBoardDTO {

}
